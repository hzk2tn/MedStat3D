# Atlas asset contract

An organ atlas is a versioned, reviewable asset bundle. The initial package has
no bundles; adding an organ requires all of the following.

1. `inst/atlas/<organ>/manifest.json` identifies the organ, atlas version,
   source, license, coordinate system, units, and supported segmentation scheme.
2. A mesh file and a segment table map every displayable mesh region to a stable
   `segment_id`.
3. Validation evidence records mesh integrity, segment coverage, orientation,
   and a visual review against the cited source.
4. An R renderer adapter consumes the manifest rather than hard-coding file
   paths or segment labels.

The public input contract is a non-empty data frame with one row per
`segment_id` and one finite numeric statistical `value`. An atlas adapter may
apply stricter requirements, such as requiring exactly the segment IDs in its
manifest. This separation keeps generic statistical validation independent of
organ-specific geometry.
